import type { Metadata } from "next";
import { Fraunces, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
  axes: ["opsz", "SOFT", "WONK"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const jbmono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jbmono",
  display: "swap",
});

const siteUrl = "https://rajkale.dev";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Raj Kale — Product Manager",
    template: "%s — Raj Kale",
  },
  description:
    "Raj Kale is a Product Manager building across fintech, consumer tech, and AI — from UPI infrastructure to post-order trust design.",
  keywords: [
    "Raj Kale",
    "Product Manager",
    "PM Portfolio",
    "Fintech Product Manager",
    "APM",
    "Product Management Intern",
    "UPI",
    "AI Product Manager",
  ],
  authors: [{ name: "Raj Kale" }],
  openGraph: {
    title: "Raj Kale — Product Manager",
    description:
      "Product Manager building across fintech, consumer tech, and AI.",
    url: siteUrl,
    siteName: "Raj Kale",
    locale: "en_US",
    type: "website",
    images: [{ url: "/images/og.jpg", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Raj Kale — Product Manager",
    description:
      "Product Manager building across fintech, consumer tech, and AI.",
    images: ["/images/og.jpg"],
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${fraunces.variable} ${inter.variable} ${jbmono.variable}`}>
      <body className="bg-ink text-parchment antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Person",
              name: "Raj Kale",
              jobTitle: "Product Manager",
              url: siteUrl,
              sameAs: ["https://linkedin.com/in/raj-kale-48009a257"],
            }),
          }}
        />
        {children}
      </body>
    </html>
  );
}
