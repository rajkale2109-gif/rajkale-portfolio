import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { projects } from "@/lib/data";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import ProjectCard from "@/components/ProjectCard";

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Metadata {
  const project = projects.find((p) => p.slug === params.slug);
  if (!project) return {};
  return {
    title: project.title,
    description: project.oneLiner,
    openGraph: { title: project.title, description: project.oneLiner },
  };
}

export default function ProjectPage({
  params,
}: {
  params: { slug: string };
}) {
  const project = projects.find((p) => p.slug === params.slug);
  if (!project) notFound();

  const others = projects.filter((p) => p.slug !== project.slug).slice(0, 3);

  return (
    <>
      <Nav />
      <main className="pt-32 pb-28">
        <div className="mx-auto max-w-3xl px-6 md:px-10">
          <Link
            href="/#projects"
            className="inline-flex items-center gap-2 text-sm text-ink-400 hover:text-amber transition-colors"
          >
            <ArrowLeft size={15} /> All projects
          </Link>

          {/* Hero banner */}
          <div className="mt-8">
            <div className="flex flex-wrap gap-2">
              {project.domain.map((d) => (
                <span
                  key={d}
                  className="text-[11px] rounded-full border border-ink-600 px-2.5 py-1 text-ink-300"
                >
                  {d}
                </span>
              ))}
              <span className="text-[11px] rounded-full border border-amber/30 px-2.5 py-1 text-amber spec-label">
                {project.status}
              </span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl text-parchment mt-6 text-balance">
              {project.title}
            </h1>
            <p className="text-lg text-ink-300 mt-4 leading-relaxed">
              {project.oneLiner}
            </p>

            {project.links.length > 0 && (
              <div className="mt-7 flex flex-wrap gap-3">
                {project.links.map((l) => (
                  <a
                    key={l.label}
                    href={l.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-full bg-amber px-5 py-2.5 text-sm font-medium text-ink-950 transition-transform hover:scale-[1.03]"
                  >
                    {l.label} <ArrowUpRight size={14} />
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Problem */}
          <section className="mt-16">
            <p className="spec-label text-[10px] text-teal mb-3">Problem</p>
            <p className="text-ink-200 leading-relaxed text-[1.05rem]">
              {project.problem}
            </p>
          </section>

          {/* Research */}
          <section className="mt-14">
            <p className="spec-label text-[10px] text-teal mb-3">Research</p>
            <ul className="space-y-3">
              {project.research.map((r) => (
                <li key={r} className="flex gap-3 text-ink-200 leading-relaxed">
                  <span className="mt-2 h-1 w-1 rounded-full bg-amber shrink-0" />
                  {r}
                </li>
              ))}
            </ul>
          </section>

          {/* Solution */}
          <section className="mt-14">
            <p className="spec-label text-[10px] text-teal mb-3">Solution</p>
            <p className="text-ink-200 leading-relaxed text-[1.05rem]">
              {project.solution}
            </p>
          </section>

          {/* Process */}
          <section className="mt-14">
            <p className="spec-label text-[10px] text-teal mb-3">
              PM Process
            </p>
            <ol className="space-y-3">
              {project.process.map((step, i) => (
                <li key={step} className="flex gap-4 text-ink-200 leading-relaxed">
                  <span className="spec-label text-[10px] text-amber shrink-0 mt-0.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </section>

          {/* Stack + Outcomes */}
          <div className="mt-14 grid sm:grid-cols-2 gap-10">
            <section>
              <p className="spec-label text-[10px] text-teal mb-3">
                Tech Stack
              </p>
              <div className="flex flex-wrap gap-2">
                {project.stack.map((s) => (
                  <span
                    key={s}
                    className="text-xs rounded-full border border-ink-600 px-3 py-1.5 text-ink-200"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </section>
            <section>
              <p className="spec-label text-[10px] text-teal mb-3">
                Outcomes
              </p>
              <ul className="space-y-2">
                {project.outcomes.map((o) => (
                  <li key={o} className="text-sm text-ink-200 flex gap-2">
                    <span className="mt-1.5 h-1 w-1 rounded-full bg-teal shrink-0" />
                    {o}
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </div>

        {/* Other projects */}
        {others.length > 0 && (
          <div className="mx-auto max-w-6xl px-6 md:px-10 mt-28">
            <p className="spec-label text-[10px] text-teal mb-6">
              More projects
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {others.map((p, i) => (
                <ProjectCard key={p.slug} project={p} index={i} />
              ))}
            </div>
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}
