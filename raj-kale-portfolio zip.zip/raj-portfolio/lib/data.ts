export type ProjectLink = {
  label: string;
  href: string;
};

export type Project = {
  slug: string;
  title: string;
  domain: string[];
  oneLiner: string;
  thumbnailTag: string; // short mono tag shown on the card, e.g. "FIN-04"
  status: "Shipped prototype" | "PRD + prototype" | "Research artifact";
  problem: string;
  research: string[];
  solution: string;
  process: string[];
  stack: string[];
  outcomes: string[];
  links: ProjectLink[];
};

export const projects: Project[] = [
  {
    slug: "paylens",
    title: "PayLens",
    domain: ["Fintech", "AI/ML"],
    oneLiner:
      "An AI expense analyzer that reads raw UPI transaction data and turns it into plain-language spending insight.",
    thumbnailTag: "AI-01",
    status: "PRD + prototype",
    problem:
      "UPI users in India generate dozens of small, fragmented transactions a week across apps, but none of those apps turn that history into an understandable picture of spending. People are left manually reconciling statements to answer a simple question: where did my money go.",
    research: [
      "Audited how existing UPI apps (GPay, PhonePe, Paytm) surface — or fail to surface — spend summaries",
      "Evaluated parsing approaches for unstructured UPI transaction strings and merchant name noise",
      "Scoped a three-layer architecture: ingestion, AI classification, and insight generation",
    ],
    solution:
      "PayLens ingests raw UPI statement data, uses the Claude API to classify and summarize transactions, and returns a categorized, plain-language breakdown of spending — reaching 92% parse accuracy on messy real-world merchant strings in testing.",
    process: [
      "Wrote the initial concept and technical architecture as the founding project of this PM portfolio",
      "Authored a full PRD (v1.1), including scope, architecture, and success metrics",
      "Exported the PRD to both Notion and a formatted document for review",
      "Designed the three-layer system: React front end, Node.js/Express backend, Claude API for classification",
    ],
    stack: ["React", "Node.js", "Express", "Claude API"],
    outcomes: [
      "92% parse accuracy on unstructured UPI transaction strings",
      "PRD v1.1 shipped as the reference document for the build",
    ],
    links: [{ label: "PRD (Notion)", href: "#" }],
  },
  {
    slug: "zepto-resolve",
    title: "Zepto Resolve",
    domain: ["Consumer Tech", "Quick Commerce"],
    oneLiner:
      "A post-order trust redesign for Zepto, rebuilding the moment between 'something went wrong' and 'it's resolved.'",
    thumbnailTag: "CT-02",
    status: "PRD + prototype",
    problem:
      "Quick-commerce orders fail in small, high-frequency ways — a missing item, a damaged product, a late delivery — and the post-order experience is where user trust is actually won or lost, not the checkout flow.",
    research: [
      "Mapped the existing post-order support journey end to end",
      "Identified friction points where users drop off before resolution",
      "Benchmarked resolution flows against other quick-commerce and delivery apps",
    ],
    solution:
      "Zepto Resolve redesigns the post-order flow around fast, transparent resolution — clearer status, fewer steps to raise an issue, and a resolution path that feels proportionate to the problem.",
    process: [
      "Wrote the full PRD in Notion, covering problem framing, flows, and success criteria",
      "Built a clickable React + Tailwind prototype to test the redesigned flow",
    ],
    stack: ["React", "Tailwind CSS"],
    outcomes: ["Working clickable prototype of the full resolution flow"],
    links: [{ label: "Live Prototype", href: "https://zepto-dash-ui.lovable.app" }],
  },
  {
    slug: "phonepe-dpdp-consent-flow",
    title: "PhonePe DPDP Guardian-Consent Flow",
    domain: ["Fintech", "Compliance", "Consumer Tech"],
    oneLiner:
      "A guardian-consent flow prototype for teen users on PhonePe, designed for compliance with India's DPDP Act.",
    thumbnailTag: "FIN-03",
    status: "PRD + prototype",
    problem:
      "India's Digital Personal Data Protection (DPDP) Act requires verifiable parental consent before minors can be onboarded to services that process their personal data — a requirement most consumer fintech apps aren't built to handle.",
    research: [
      "Studied the DPDP Act's specific requirements around minors and verifiable consent",
      "Mapped what a compliant guardian-consent flow needs to capture without breaking onboarding",
    ],
    solution:
      "A clickable guardian-consent flow that walks a teen user and their guardian through DPDP-compliant verification before a PhonePe account is activated for a minor.",
    process: [
      "Built as a PM intern assignment for Vedantu",
      "Designed the full flow in React and Tailwind as an interactive simulation",
      "Produced an 11-slide product deck walking through the problem, flow, and rationale",
    ],
    stack: ["React", "Tailwind CSS"],
    outcomes: ["11-slide product deck delivered alongside the working prototype"],
    links: [
      { label: "Live Prototype", href: "https://teen-consent-sim.lovable.app" },
    ],
  },
  {
    slug: "pauseflow",
    title: "PauseFlow",
    domain: ["Fintech", "B2B SaaS", "Infrastructure"],
    oneLiner:
      "Infrastructure for pausing NACH auto-debits on demand — giving users control banks don't currently offer.",
    thumbnailTag: "FIN-04",
    status: "Research artifact",
    problem:
      "NACH auto-debit mandates in India are simple to set up and painful to pause. A user who wants to temporarily stop a recurring debit — during a cash crunch, for example — has no self-serve way to do it.",
    research: [
      "Studied how NACH mandates are created, modified, and cancelled today",
      "Scoped where a pause primitive would sit in the existing mandate lifecycle",
    ],
    solution:
      "PauseFlow proposes a pause primitive for NACH mandates: a defined, reversible state between active and cancelled, with clear wireframed flows for both end users and the businesses managing the mandate.",
    process: [
      "Produced a full PM artifact covering the problem, proposed flow, and infrastructure implications",
      "Wrote out wireframe descriptions for the core pause / resume flow",
    ],
    stack: ["Product Spec", "Wireframes"],
    outcomes: ["Complete PM artifact defining a pause primitive for NACH infrastructure"],
    links: [],
  },
  {
    slug: "upi-payment-failure-ux",
    title: "UPI Payment Failure UX",
    domain: ["Fintech", "UX Research"],
    oneLiner:
      "Primary research into why UPI payment failures feel so disorienting — and a competitive audit of how the major apps handle them.",
    thumbnailTag: "RES-01",
    status: "Research artifact",
    problem:
      "When a UPI payment fails or hangs, users are rarely told what actually happened — did the money leave, is it stuck, will it reverse — and every major app handles that ambiguity differently.",
    research: [
      "Conducted primary research directly with UPI users on their experience of payment failures",
      "Ran a competitive audit of failure-state handling across GPay, PhonePe, Paytm, and BHIM",
    ],
    solution:
      "A 13-section case study documenting failure patterns, comparing how each app communicates (or fails to communicate) status, and proposing where the experience should converge on clarity.",
    process: [
      "Synthesized primary research and competitive audit into a structured case study",
      "Produced two versions of the write-up plus shareable LinkedIn post variants",
    ],
    stack: ["User Research", "Competitive Analysis"],
    outcomes: ["13-section case study grounded in primary user research"],
    links: [],
  },
];

export type ExperienceItem = {
  role: string;
  org: string;
  period: string;
  points: string[];
};

export const experience: ExperienceItem[] = [
  {
    role: "Product Management Intern",
    org: "Innovative Staffing Solutions",
    period: "Current",
    points: [
      "Working on live product management problems as part of an active PM internship track.",
    ],
  },
  {
    role: "Research Intern",
    org: "PICT Research Lab",
    period: "Ongoing",
    points: [
      "Conducting research under the guidance of Mr. R. C. Jaiswal.",
      "Co-authored a paper accepted at ICCCNet-2025, indexed by Springer, hosted at Manchester Metropolitan University, UK.",
    ],
  },
];

export const publication = {
  title: "ICCCNet-2025",
  venue: "Manchester Metropolitan University, UK",
  indexing: "Springer-indexed international publication",
  advisor: "Mr. R. C. Jaiswal, PICT Research Lab",
};

export const skills = {
  Product: [
    "PRD writing",
    "Product roadmapping",
    "Competitive analysis",
    "User research",
    "Problem framing",
  ],
  Research: [
    "Primary user research",
    "Academic research",
    "Competitive audits",
  ],
  "Design & Prototyping": [
    "Clickable prototyping",
    "Wireframing",
    "Figma",
  ],
  Technical: ["React", "Node.js / Express", "Claude API", "Git"],
  Tools: ["Notion", "Lovable", "LaTeX"],
};

export const profile = {
  name: "Raj Kale",
  role: "Product Manager",
  tagline: "Building products across fintech, consumer tech, and AI.",
  location: "Pune, India",
  education:
    "Electronics & Telecommunication Engineering, PICT Pune — graduating May 2027",
  linkedin: "https://linkedin.com/in/raj-kale-48009a257",
};
