"use client";

import { motion } from "framer-motion";
import { profile } from "@/lib/data";

const pillars = [
  {
    label: "Research",
    body: "Primary user research and academic research aren't separate muscles for me — both start with the same question: what's actually happening, not what I assume is happening.",
  },
  {
    label: "Process",
    body: "Every project here has a PRD behind it. I write the problem down before I design the solution, and I write the solution down before I prototype it.",
  },
  {
    label: "Range",
    body: "UPI infrastructure, DPDP compliance, quick-commerce trust, AI classification — the domain changes, the method doesn't.",
  },
];

export default function About() {
  return (
    <section id="about" className="relative py-28 md:py-36">
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="spec-label text-[11px] text-teal mb-4"
        >
          01 &middot; About
        </motion.div>

        <div className="grid md:grid-cols-[1fr_1fr] gap-16">
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7 }}
            className="font-display text-2xl sm:text-3xl leading-snug text-parchment text-balance"
          >
            I'm an Electronics & Telecommunication Engineering student at
            PICT Pune who kept ending up on the product side of every
            technical problem I touched — so I stopped resisting it.
          </motion.p>

          <div className="space-y-8">
            <motion.p
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.7, delay: 0.05 }}
              className="text-ink-300 leading-relaxed"
            >
              My work sits at the intersection of research and shipping. I
              started in fintech — UPI failures, NACH infrastructure,
              compliance flows — because payments is where small UX
              decisions have outsized consequences. From there I moved into
              consumer tech and AI, building an expense analyzer on top of
              the Claude API and redesigning post-order trust for
              quick-commerce. Alongside that, I've spent time in a research
              lab, co-authoring a paper that made it into a Springer-indexed
              conference.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-ink-300 leading-relaxed"
            >
              I care less about which industry I'm in than about whether I
              can find the real problem underneath the stated one — and
              whether I can get from that problem to a working prototype
              fast enough to test it.
            </motion.p>
            <p className="text-sm text-ink-400">{profile.education}</p>
          </div>
        </div>

        <div className="mt-20 grid sm:grid-cols-3 gap-6">
          {pillars.map((p, i) => (
            <motion.div
              key={p.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
              className="rounded-2xl border border-ink-700 bg-ink-900/40 p-6 hover:border-amber/40 transition-colors"
            >
              <p className="spec-label text-[10px] text-amber mb-3">
                {p.label}
              </p>
              <p className="text-sm text-ink-300 leading-relaxed">{p.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
