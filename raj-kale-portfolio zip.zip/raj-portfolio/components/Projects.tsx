"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { projects } from "@/lib/data";
import ProjectCard from "./ProjectCard";

export default function Projects() {
  const domains = useMemo(() => {
    const set = new Set<string>();
    projects.forEach((p) => p.domain.forEach((d) => set.add(d)));
    return ["All", ...Array.from(set)];
  }, []);

  const [active, setActive] = useState("All");

  const filtered =
    active === "All" ? projects : projects.filter((p) => p.domain.includes(active));

  return (
    <section id="projects" className="relative py-28 md:py-36">
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="spec-label text-[11px] text-teal mb-4"
        >
          03 &middot; Projects
        </motion.div>
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="font-display text-3xl sm:text-4xl text-parchment"
          >
            Case studies, not case screenshots.
          </motion.h2>

          <div className="flex flex-wrap gap-2">
            {domains.map((d) => (
              <button
                key={d}
                onClick={() => setActive(d)}
                className={`spec-label text-[10px] rounded-full px-3.5 py-1.5 border transition-colors ${
                  active === d
                    ? "bg-amber text-ink-950 border-amber"
                    : "border-ink-600 text-ink-300 hover:border-amber/50 hover:text-amber"
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((p, i) => (
            <ProjectCard key={p.slug} project={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
