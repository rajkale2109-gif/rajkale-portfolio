"use client";

import { motion } from "framer-motion";
import { Linkedin, Mail, Download } from "lucide-react";
import { profile } from "@/lib/data";

export default function Contact() {
  return (
    <section id="contact" className="relative py-28 md:py-36 bg-ink-900/30">
      <div className="mx-auto max-w-4xl px-6 md:px-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="spec-label text-[11px] text-teal mb-4"
        >
          06 &middot; Contact
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="font-display text-3xl sm:text-4xl text-parchment text-balance"
        >
          Working on a product problem worth talking about?
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mt-5 text-ink-300"
        >
          I'm currently looking for Product Management internships and APM
          roles. Based in {profile.location}, open to remote.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="mailto:hello@rajkale.dev"
            className="inline-flex items-center gap-2 rounded-full bg-amber px-6 py-3 text-sm font-medium text-ink-950 transition-transform hover:scale-[1.03] active:scale-95"
          >
            <Mail size={16} /> Email me
          </a>
          <a
            href={profile.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3 text-sm text-parchment transition-colors hover:border-teal hover:text-teal"
          >
            <Linkedin size={16} /> LinkedIn
          </a>
          <a
            href="/resume.pdf"
            className="inline-flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3 text-sm text-parchment transition-colors hover:border-amber hover:text-amber"
          >
            <Download size={16} /> Resume
          </a>
        </motion.div>
      </div>
    </section>
  );
}
