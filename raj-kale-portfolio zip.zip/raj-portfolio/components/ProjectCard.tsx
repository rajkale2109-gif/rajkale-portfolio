"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { Project } from "@/lib/data";

export default function ProjectCard({
  project,
  index,
}: {
  project: Project;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.08 }}
      className="group relative rounded-2xl border border-ink-700 bg-ink-900/50 overflow-hidden hover:border-amber/50 transition-colors"
    >
      <Link href={`/projects/${project.slug}`} className="block p-6 sm:p-7">
        <div className="flex items-start justify-between">
          <span className="spec-label text-[10px] text-amber border border-amber/30 rounded px-2 py-1">
            {project.thumbnailTag}
          </span>
          <ArrowUpRight
            size={18}
            className="text-ink-400 group-hover:text-amber group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all"
          />
        </div>

        <h3 className="font-display text-2xl text-parchment mt-5">
          {project.title}
        </h3>
        <p className="text-sm text-ink-300 leading-relaxed mt-3">
          {project.oneLiner}
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          {project.domain.map((d) => (
            <span
              key={d}
              className="text-[11px] rounded-full border border-ink-600 px-2.5 py-1 text-ink-300"
            >
              {d}
            </span>
          ))}
        </div>

        <div className="mt-6 pt-5 border-t border-ink-700 flex items-center justify-between">
          <span className="spec-label text-[10px] text-ink-400">
            {project.status}
          </span>
          <span className="text-xs text-teal group-hover:underline underline-offset-4">
            Case study
          </span>
        </div>
      </Link>
    </motion.div>
  );
}
