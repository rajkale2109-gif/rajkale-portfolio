"use client";

import { motion } from "framer-motion";
import { FileText } from "lucide-react";
import { publication } from "@/lib/data";

export default function Research() {
  return (
    <section id="research" className="relative py-28 md:py-36 bg-ink-900/30">
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="spec-label text-[11px] text-teal mb-4"
        >
          04 &middot; Research
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="font-display text-3xl sm:text-4xl text-parchment mb-12"
        >
          Published research.
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6 }}
          className="rounded-2xl border border-ink-700 bg-ink-900/60 p-8 flex flex-col sm:flex-row gap-6 sm:items-center"
        >
          <div className="h-14 w-14 rounded-xl bg-amber/10 flex items-center justify-center shrink-0">
            <FileText className="text-amber" size={24} />
          </div>
          <div>
            <p className="spec-label text-[10px] text-amber mb-2">
              {publication.indexing}
            </p>
            <h3 className="font-display text-xl text-parchment">
              {publication.title}
            </h3>
            <p className="text-sm text-ink-300 mt-1">{publication.venue}</p>
            <p className="text-xs text-ink-400 mt-3">
              Research conducted at PICT Research Lab, under the guidance of{" "}
              {publication.advisor.replace(", PICT Research Lab", "")}.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
