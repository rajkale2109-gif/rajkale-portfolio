"use client";

import { motion } from "framer-motion";
import { experience } from "@/lib/data";

export default function Experience() {
  return (
    <section id="experience" className="relative py-28 md:py-36 bg-ink-900/30">
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="spec-label text-[11px] text-teal mb-4"
        >
          02 &middot; Experience
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="font-display text-3xl sm:text-4xl text-parchment mb-16"
        >
          Where I've been building.
        </motion.h2>

        <div className="relative border-l border-ink-700 pl-8 space-y-14">
          {experience.map((item, i) => (
            <motion.div
              key={item.org}
              initial={{ opacity: 0, x: 24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="relative"
            >
              <span className="absolute -left-[2.28rem] top-1.5 h-3 w-3 rounded-full bg-amber shadow-[0_0_0_4px_rgba(212,168,87,0.15)]" />
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <h3 className="font-display text-xl text-parchment">
                  {item.role}
                </h3>
                <span className="spec-label text-[10px] text-ink-400">
                  {item.period}
                </span>
              </div>
              <p className="text-teal text-sm mt-1">{item.org}</p>
              <ul className="mt-4 space-y-2">
                {item.points.map((pt) => (
                  <li
                    key={pt}
                    className="text-sm text-ink-300 leading-relaxed flex gap-2"
                  >
                    <span className="text-amber mt-1.5 h-1 w-1 rounded-full bg-amber shrink-0" />
                    {pt}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
