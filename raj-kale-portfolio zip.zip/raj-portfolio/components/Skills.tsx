"use client";

import { motion } from "framer-motion";
import { skills } from "@/lib/data";

export default function Skills() {
  const categories = Object.entries(skills);

  return (
    <section className="relative py-28 md:py-36">
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="spec-label text-[11px] text-teal mb-4"
        >
          05 &middot; Skills
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="font-display text-3xl sm:text-4xl text-parchment mb-14"
        >
          The toolkit behind the projects.
        </motion.h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map(([cat, list], i) => (
            <motion.div
              key={cat}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.06 }}
              className="rounded-2xl border border-ink-700 bg-ink-900/40 p-6 hover:border-teal/40 transition-colors"
            >
              <p className="spec-label text-[10px] text-teal mb-4">{cat}</p>
              <div className="flex flex-wrap gap-2">
                {list.map((s) => (
                  <span
                    key={s}
                    className="text-xs rounded-full border border-ink-600 px-3 py-1.5 text-ink-200 hover:border-amber/50 hover:text-amber transition-colors"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
