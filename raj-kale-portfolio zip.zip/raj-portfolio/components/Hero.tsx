"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { ArrowDown, Download, Linkedin } from "lucide-react";
import { profile } from "@/lib/data";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative min-h-screen flex items-center overflow-hidden pt-24 pb-20"
    >
      {/* ambient gradient field */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-40 -left-40 h-[36rem] w-[36rem] rounded-full bg-amber/10 blur-[120px] animate-float-slow" />
        <div className="absolute top-1/3 -right-40 h-[30rem] w-[30rem] rounded-full bg-teal/10 blur-[120px] animate-float-slower" />
        <div className="absolute inset-0 bg-grain mix-blend-overlay opacity-40" />
      </div>

      <div className="mx-auto max-w-6xl w-full px-6 md:px-10 grid md:grid-cols-[1.15fr_0.85fr] gap-14 items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="spec-label text-[11px] text-amber mb-6 flex items-center gap-3"
          >
            <span className="h-px w-8 bg-amber/60" />
            Product Manager &middot; {profile.location}
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-balance text-[2.75rem] leading-[1.05] sm:text-6xl md:text-[3.6rem] text-parchment"
          >
            Products fail quietly.
            <br />
            <span className="text-ink-300">I go find where.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-7 max-w-lg text-lg leading-relaxed text-ink-300"
          >
            I'm Raj — a Product Manager who moves between fintech, consumer
            tech, and AI, tracing user problems from a failed UPI payment to
            a compliance gap to a support flow nobody trusts. I write the
            PRD, build the prototype, and ship the thing that closes the
            gap.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <a
              href="#projects"
              className="group inline-flex items-center gap-2 rounded-full bg-amber px-6 py-3 text-sm font-medium text-ink-950 transition-transform hover:scale-[1.03] active:scale-95"
            >
              View projects
            </a>
            <a
              href="/resume.pdf"
              className="inline-flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3 text-sm text-parchment transition-colors hover:border-amber hover:text-amber"
            >
              <Download size={16} /> Resume
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-ink-600 px-6 py-3 text-sm text-parchment transition-colors hover:border-teal hover:text-teal"
            >
              <Linkedin size={16} /> LinkedIn
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="relative mx-auto"
        >
          <div className="relative h-64 w-64 sm:h-80 sm:w-80 rounded-[2rem] overflow-hidden">
            <div className="absolute -inset-[2px] rounded-[2rem] bg-[conic-gradient(from_0deg,#D4A857,#4FD1C5,#D4A857)] animate-[spin_8s_linear_infinite]" />
            <div className="absolute inset-[3px] rounded-[1.85rem] overflow-hidden bg-ink-900">
              <Image
                src="/images/profile.jpg"
                alt="Portrait of Raj Kale"
                fill
                priority
                sizes="(max-width: 768px) 256px, 320px"
                className="object-cover"
              />
            </div>
          </div>
          <div className="absolute -bottom-5 -left-5 rounded-xl border border-ink-700 bg-ink-900/90 backdrop-blur px-4 py-2.5 shadow-xl">
            <p className="spec-label text-[10px] text-teal">Publication</p>
            <p className="text-xs text-ink-200 mt-0.5">ICCCNet-2025 &middot; Springer</p>
          </div>
        </motion.div>
      </div>

      <motion.a
        href="#about"
        aria-label="Scroll to About section"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-ink-400 hover:text-amber transition-colors"
      >
        <ArrowDown size={20} />
      </motion.a>
    </section>
  );
}
