"use client";

import { ArrowUp } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-ink-700 py-8">
      <div className="mx-auto max-w-6xl px-6 md:px-10 flex items-center justify-between">
        <p className="text-xs text-ink-400">
          &copy; {new Date().getFullYear()} Raj Kale. Built with intent.
        </p>
        <a
          href="#top"
          aria-label="Back to top"
          className="h-9 w-9 flex items-center justify-center rounded-full border border-ink-600 text-ink-300 hover:border-amber hover:text-amber transition-colors"
        >
          <ArrowUp size={16} />
        </a>
      </div>
    </footer>
  );
}
